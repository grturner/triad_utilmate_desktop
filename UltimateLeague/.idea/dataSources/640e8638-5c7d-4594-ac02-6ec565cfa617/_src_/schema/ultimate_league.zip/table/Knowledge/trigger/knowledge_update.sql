CREATE TRIGGER knowledge_update
BEFORE UPDATE ON Knowledge
FOR EACH ROW
  begin
	insert into Knowledge_audit
	set action = 'update',
   Player_ID = OLD.Player_ID,
    Experience_Name = OLD.Experience_Name,
    Position_Name = OLD.Position_Name,
    changedat = NOW();
end;
