CREATE PROCEDURE CheckPassword(IN username VARCHAR(20), IN password VARCHAR(20))
  BEGIN


IF EXISTS(SELECT * FROM Logon WHERE User_Name = username AND Pass_Word = password)

THEN
    SELECT 'true' AS UserExists;
ELSE
    SELECT 'false' AS UserExists;
    
END IF;

END;
