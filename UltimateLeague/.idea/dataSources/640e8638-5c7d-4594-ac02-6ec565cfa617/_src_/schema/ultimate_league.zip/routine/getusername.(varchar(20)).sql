CREATE PROCEDURE getusername(IN UserName VARCHAR(20))
  begin
select * 
from Logon
where User_Name = UserName;
end;
